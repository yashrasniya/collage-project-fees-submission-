# from options._email import *
#
#
# data = ['hi','Done']
# email_confection(data,'yashrasniya3@gmail.com')

